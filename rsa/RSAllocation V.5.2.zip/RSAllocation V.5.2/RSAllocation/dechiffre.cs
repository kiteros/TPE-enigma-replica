﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Numerics;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RSAllocation
{
    public partial class dechiffre : Form
    {
        int taillebloc;
        int n;
        int d;
        String textCrypt;
        int lettre_crypt;
        int ascii;
        int i;
        int tailleascii;
        int newlistcrypt;
        string listcrypt;
        int crypt;
        string strascii;
        int taillechaine;
        int taillechaineespace;
        int espace;
        char lettre;

        public dechiffre()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            d = Int32.Parse(textBox1.Text);
            n = Int32.Parse(textBox2.Text);
            taillebloc = Int32.Parse(textBox5.Text);
            taillechaine = 0;
            textCrypt = textBox3.Text.ToString();
            i = textCrypt.Split(' ').Count() + 1;
            String[] list_bloc = textCrypt.Split(' ');
            int taille = list_bloc.Count();

            for (int compteur = 0; compteur < taille; compteur++)
            {
                lettre_crypt = Int32.Parse((string)list_bloc[compteur]);
                BigInteger ascii = BigInteger.ModPow(lettre_crypt , d, n);
                tailleascii = ascii.ToString().Length;

                if(tailleascii < taillebloc)
                {   

                    strascii += ascii;
                    taillechaine += ascii.ToString().Length + 1;
                    espace++;
                    strascii = strascii.Insert(0, "0");
                    listcrypt += strascii + " ";
                    strascii = "";

                }

                else
                {

                    listcrypt += ascii + " ";
                    espace++;
                    taillechaine += ascii.ToString().Length;
                }
                    
            }
            //pour le dernier bloc le 0 est enlevé si la longueur de tout les nombre n'est pas egale a un multiple de 3 
            if (taillechaine % 3 != 0)
            {

                espace = (espace - 1) * taillebloc + espace - 1 ;
                listcrypt = listcrypt.Remove(espace, 1);

            }

            listcrypt = listcrypt.Replace(" ", String.Empty);
            //textBox4.AppendText(listcrypt);
            for (int i = 3; i <= listcrypt.Length; i += 3)
            {
                listcrypt = listcrypt.Insert(i, " ");
                i++;
            }

            String[] newlistcrypt = listcrypt.Split(' ');

            for (int f = 0; f < newlistcrypt.Count() - 1; f++)
            {


                crypt = Int32.Parse(newlistcrypt[f]);
                lettre = ((char)crypt);
                textBox4.AppendText(lettre.ToString());
            }

            //textBox4.AppendText(((char)ascii).ToString());


        }
    }
}
