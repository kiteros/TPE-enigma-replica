﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Numerics;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RSAllocation
{
    public partial class chiffre : Form
    {
        int ee;
        int w;
        int taille;
        string listcrypt;
        int n;
        int taille_du_mot;
        int ascii;
        int taillelist;
        int nbbloc;
        public chiffre()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ee = Int32.Parse(textBox1.Text);
            n = Int32.Parse(textBox2.Text);
            taille = Int32.Parse(textBox5.Text);
            string mot = textBox3.Text;
            taille_du_mot = mot.Length;
            int i = 0;
            List<int> phraseCrypt = new List<int>();
            while (i < taille_du_mot)
            {
                ascii = (int)(mot[i]);
                if (ascii < 100)
                {
                    string newascii = "0" + ascii.ToString();
                    listcrypt = listcrypt + newascii;
                }
                else
                {
                    listcrypt = listcrypt + ascii;
                }
                
                i++;
            }

            taillelist = listcrypt.Length;
            w = taillelist / taille;

            if (w * taille == taillelist)
            {
                for (int g = 1; g < w; g++)
                {
                    listcrypt = listcrypt.Insert(taille * g + g - 1, " ");
                }
            }

            else
            {
                for (int g = 1; g < w+1; g++)
                {
                    listcrypt = listcrypt.Insert(taille* g +g - 1, " ");
                }
            }


            //textBox4.AppendText(listcrypt);

            String[] bloc_ascii = listcrypt.Split(' ');
            nbbloc = bloc_ascii.Count();
            for (int g = 0; g < nbbloc; g++)
            {

                ascii = Int32.Parse((string)bloc_ascii[g]);
                BigInteger lettre_crypt = BigInteger.Pow(ascii, ee) % n;

                phraseCrypt.Add((int)lettre_crypt);
                i++;
            }


            for (int f = 0; f < (phraseCrypt.Count()); f++)
            {   

                if(f + 1 == phraseCrypt.Count())
                {
                    textBox4.AppendText(phraseCrypt[f].ToString());
                }

                else
                {
                    textBox4.AppendText(phraseCrypt[f].ToString() + " ");
                }


            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}